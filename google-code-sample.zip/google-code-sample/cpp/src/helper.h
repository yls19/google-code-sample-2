#pragma once

#include <string>

std::string trim(std::string s);

std::vector<std::string> splitlines(std::string output);
